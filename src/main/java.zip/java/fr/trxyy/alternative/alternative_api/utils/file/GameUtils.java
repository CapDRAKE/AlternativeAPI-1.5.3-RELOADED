package fr.trxyy.alternative.alternative_api.minecraft.utils;

import fr.trxyy.alternative.alternative_api.GameEngine;
import fr.trxyy.alternative.alternative_api.GameFolder;
import fr.trxyy.alternative.alternative_api.minecraft.json.MinecraftLibrary;
import fr.trxyy.alternative.alternative_api.minecraft.json.MinecraftVersion;

import java.io.File;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;

/**
 * Classpath utilities used by the launcher.
 *
 * Legacy Forge (1.7.10 -> 1.12.2) still relies on LaunchWrapper and a few extra
 * libraries that are not always present in the base Minecraft version json.
 * This implementation keeps the original behavior for vanilla / modern versions,
 * but also injects Forge-declared libraries when available and falls back to the
 * mandatory legacy jars when LaunchWrapper is the selected entrypoint.
 */
public class GameUtils {

    public static File getWorkingDirectory(String workDir) {
        String userHome = System.getProperty("user.home", ".");
        File workingDirectory;
        switch (getPlatform()) {
            case 1:
                workingDirectory = new File(userHome + "/." + workDir);
            case 2:
                workingDirectory = new File(userHome + "/." + workDir);
                break;
            case 3:
                workingDirectory = new File(userHome + "\\AppData\\Roaming\\." + workDir);
                break;
            case 4:
                workingDirectory = new File(userHome + "/Library/Application Support/" + workDir);
                break;
            default:
                workingDirectory = new File(userHome + "/." + workDir);
        }
        return workingDirectory;
    }

    private static int getPlatform() {
        String osName = System.getProperty("os.name").toLowerCase();
        if (osName.contains("linux")) return 1;
        if (osName.contains("unix")) return 1;
        if (osName.contains("solaris")) return 2;
        if (osName.contains("sunos")) return 2;
        if (osName.contains("win")) return 3;
        if (osName.contains("mac")) return 4;
        return 5;
    }

    /**
     * Build the runtime classpath.
     *
     * Vanilla libraries always come from the Minecraft version json.
     * For Forge, we also try to append libraries declared by GameForge / forge json.
     * For old Forge generations we finally ensure LaunchWrapper is present.
     */
    public static String constructClasspath(MinecraftVersion mcVersion, GameEngine engine) {
        GameFolder workDir = engine.getGameFolder();
        String separator = System.getProperty("path.separator");
        LinkedHashSet<String> entries = new LinkedHashSet<>();

        for (File lib : getMinecraftLibraries(mcVersion, engine)) {
            addClasspathEntry(entries, lib, false);
        }

        addForgeLibraries(engine, entries);
        addLegacyForgeFallbackLibraries(engine, entries);

        File versionFolder = new File(workDir.getVersionsDir(), mcVersion.getId());
        File versionJar = new File(versionFolder, mcVersion.getId() + ".jar");
        addClasspathEntry(entries, versionJar, false);

        StringBuilder result = new StringBuilder();
        for (String entry : entries) {
            result.append(entry).append(separator);
        }
        if (result.length() >= separator.length()) {
            result.setLength(result.length() - separator.length());
        }
        return result.toString();
    }

    private static void addForgeLibraries(GameEngine engine, LinkedHashSet<String> entries) {
        if (engine == null || engine.getGameFolder() == null) {
            return;
        }

        Object gameForge = invoke(engine, "getGameForge");
        if (gameForge == null) {
            return;
        }

        Object libraries = invoke(gameForge, "getLibraries");
        if (!(libraries instanceof Collection)) {
            return;
        }

        GameFolder workDir = engine.getGameFolder();
        for (Object lib : (Collection<?>) libraries) {
            if (!appliesToCurrentEnvironment(lib)) {
                continue;
            }

            File libFile = resolveLibraryFile(workDir, lib);
            if (libFile != null) {
                addClasspathEntry(entries, libFile, true);
            }
        }
    }

    /**
     * Very old Forge needs LaunchWrapper and sometimes a couple of extra jars.
     * Those jars can already be downloaded even when the forge json parser did not
     * surface them in getLibraries(). So we add them as a safe fallback if present.
     */
    private static void addLegacyForgeFallbackLibraries(GameEngine engine, LinkedHashSet<String> entries) {
        if (!usesLegacyLaunchWrapper(engine) || engine == null || engine.getGameFolder() == null) {
            return;
        }

        GameFolder workDir = engine.getGameFolder();
        addIfExists(entries, new File(workDir.getLibsDir(), "net/minecraft/launchwrapper/1.12/launchwrapper-1.12.jar"));
        addIfExists(entries, new File(workDir.getLibsDir(), "org/ow2/asm/asm-all/5.2/asm-all-5.2.jar"));
        addIfExists(entries, new File(workDir.getLibsDir(), "jline/jline/2.13/jline-2.13.jar"));
    }

    private static boolean usesLegacyLaunchWrapper(GameEngine engine) {
        try {
            Object style = invoke(engine, "getGameStyle");
            if (style != null) {
                String styleName = String.valueOf(style);
                if (styleName.contains("FORGE_1_7_10") || styleName.contains("FORGE_1_8_TO_1_12_2")) {
                    return true;
                }
            }

            Object forge = invoke(engine, "getGameForge");
            Object args = forge == null ? null : invoke(forge, "getArguments");
            Object gameArgs = args == null ? null : invoke(args, "getGame");
            if (gameArgs instanceof List) {
                List<?> values = (List<?>) gameArgs;
                for (Object value : values) {
                    if (value != null && String.valueOf(value).contains("FMLTweaker")) {
                        return true;
                    }
                }
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    private static boolean appliesToCurrentEnvironment(Object lib) {
        if (lib == null) {
            return false;
        }

        Object result = invoke(lib, "appliesToCurrentEnvironment");
        if (result instanceof Boolean) {
            return (Boolean) result;
        }
        return true;
    }

    private static File resolveLibraryFile(GameFolder workDir, Object lib) {
        if (workDir == null || lib == null) {
            return null;
        }

        Object artifactPath = invoke(lib, "getArtifactPath");
        if (artifactPath instanceof String && !((String) artifactPath).isEmpty()) {
            return new File(workDir.getLibsDir(), (String) artifactPath);
        }

        Object path = invoke(lib, "getPath");
        if (path instanceof String && !((String) path).isEmpty()) {
            return new File(workDir.getLibsDir(), (String) path);
        }

        Object name = invoke(lib, "getName");
        if (name instanceof String) {
            String artifact = mavenToArtifactPath((String) name);
            if (artifact != null) {
                return new File(workDir.getLibsDir(), artifact);
            }
        }

        return null;
    }

    private static String mavenToArtifactPath(String notation) {
        // group:artifact:version[:classifier][@ext]
        if (notation == null || notation.trim().isEmpty()) {
            return null;
        }

        String extension = "jar";
        String value = notation;
        int atIndex = value.indexOf('@');
        if (atIndex >= 0) {
            extension = value.substring(atIndex + 1);
            value = value.substring(0, atIndex);
        }

        String[] parts = value.split(":");
        if (parts.length < 3) {
            return null;
        }

        String group = parts[0].replace('.', '/');
        String artifact = parts[1];
        String version = parts[2];
        String classifier = parts.length >= 4 ? parts[3] : null;

        StringBuilder fileName = new StringBuilder();
        fileName.append(artifact).append('-').append(version);
        if (classifier != null && !classifier.trim().isEmpty()) {
            fileName.append('-').append(classifier);
        }
        fileName.append('.').append(extension);

        return group + "/" + artifact + "/" + version + "/" + fileName;
    }

    private static void addIfExists(LinkedHashSet<String> entries, File file) {
        if (file != null && file.exists()) {
            addClasspathEntry(entries, file, true);
        }
    }

    private static void addClasspathEntry(LinkedHashSet<String> entries, File file, boolean allowUniversal) {
        if (file == null) {
            return;
        }

        String path = file.getAbsolutePath();
        String normalized = path.replace('\\', '/').toLowerCase();

        if (normalized.contains("-srg")) {
            return;
        }
        if (normalized.contains("-extra")) {
            return;
        }
        if (normalized.contains("fmlcore") && !allowUniversal) {
            return;
        }
        if (normalized.contains("javafmllanguage") && !allowUniversal) {
            return;
        }
        if (normalized.contains("mclanguage") && !allowUniversal) {
            return;
        }
        if (normalized.contains("-universal") && !allowUniversal) {
            return;
        }

        entries.add(path);
    }

    private static Object invoke(Object target, String methodName) {
        if (target == null) {
            return null;
        }
        try {
            Method method = target.getClass().getMethod(methodName);
            method.setAccessible(true);
            return method.invoke(target);
        } catch (Exception ignored) {
            return null;
        }
    }

    private static ArrayList<File> getMinecraftLibraries(MinecraftVersion minecraftVersion, GameEngine engine) {
        ArrayList<File> theLibraries = new ArrayList<>();
        GameFolder workDir = engine.getGameFolder();
        for (MinecraftLibrary lib : minecraftVersion.getLibraries()) {
            if (lib.appliesToCurrentEnvironment()) {
                File libPath = new File(workDir.getLibsDir(), lib.getArtifactPath());
                theLibraries.add(libPath);
            }
        }
        return theLibraries;
    }

    public static ArrayList<File> list(File folder) {
        ArrayList<File> files = new ArrayList<>();
        if (!folder.isDirectory()) return files;
        File[] folderFiles = folder.listFiles();
        if (folderFiles != null) {
            for (File f : folderFiles) {
                if (f.isDirectory()) files.addAll(list(f));
                else files.add(f);
            }
        }
        return files;
    }
}
